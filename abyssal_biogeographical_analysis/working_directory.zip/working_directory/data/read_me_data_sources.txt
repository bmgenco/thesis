			    
				PLACE ALL UNZIPPED DATA FILES IN THIS DIRECTORY				


					Data Sources and References


##################################################################################################################

					BIOLOGICAL DATASETS
GBIF

1: Martinez Arbizu, P. Smith, C. R., Keller, S. and Ebbe, B. (Editors). Biogeographic Database
of the Census of Abyssal Marine Life. [Oct 12 2015]. World Wide Web electronic publication.
Available online at http://www.cedamar.org/ doi:10.15468/oc9tsb

2: Senckenberg -CeDAMar Provider: Senckenberg - CeDAMar Resource. doi:10.15468/oc9tsb
Accessed via http://www.gbif.org/dataset/96180cd0-f762-11e1-a439-00145eb45e9a on Oct 12 2015

3: GBIF.org (12th October 2015) GBIF Occurrence Download http://doi.org/10.15468/dl.ru90yk
Query: Dataset Senckenberg - CeDAMar Resource

CeDAMar

1:	Unpublished CeDAMar, courtesy Dr. Camilo Mora. Available via github data repository.
https://github.com/bmgenco/thesis/
Note, this is a raw data set make sure to double check fo errors. Misspellings in taxanominc fields, 9999 as NUll in Max Depth field.

2: 	Stuart CT, Arbizu PM, Smith CR, Molodtsova T, Brandt A, Etter RJ, Escobar-Briones E, Fabri MC, Rex MA.
CeDAMar global database of abyssal biological sampling. Aquatic Biology. 2008 Dec 1;4:143-5.


##################################################################################################################
				
					PROVINCES

1: 	Shape files courtsey of Dr. Les Watling. Contact Dr. Watling for use in publication.

2:	Watling L, Guinotte J, Clark MR, Smith CR. A proposed biogeography of the deep ocean floor. 
Progress in Oceanography. 2013 Apr 1;111:91-112.

##################################################################################################################

					Physical DATA
Land and ocean map data:

1: Natural Earth. Free vector and raster map data @ naturalearthdata.com.

"nenc.rda"

r object was created from (see script six.r) Smith and Sandwell 30-Plus v.11  30 arc second global topography. 
This require conversion,0-360 longitude -> -180 - 180 longitude. Then subsettinfg for region of interest.
Which can be accomplished using command line GMT tools:            
        
$ GMT grdedit strmthirty.grd −R-180/180/-90/90 −S                   
$ GMT grdreformat strmthirty.grd -R-75/-60/31.5/42.5 ne.grd 

SRTM: Topography: http://topex.ucsd.edu/WWW_html/srtm30_plus.html
GSHHG: https://www.ngdc.noaa.gov/mgg/shorelines/gshhs.html
GMT tools: http://gmt.soest.hawaii.edu

##################################################################################################################



